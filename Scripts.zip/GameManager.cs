﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    // 生成障碍物点列表（장애물 목록 생성）
    public List<Transform> bornPosList = new List<Transform>();
    // 道路列表（도로 목록）
    public List<Transform> roadList = new List<Transform>();
    // 抵达点列表（도착 지점 목록）
    public List<Transform> arrivePosList = new List<Transform>();
    // 障碍物列表（장애물 목록）
    public List<GameObject> objPrefabList = new List<GameObject>();
    // 目前的障碍物（현재의 장애물）
    Dictionary<string, List<GameObject>> objDict = new Dictionary<string, List<GameObject>>();
    public int roadDistance;
    public bool isEnd = false;
    // Use this for initialization
    void Start()
    {
        foreach (Transform road in roadList)
        {
            List<GameObject> objList = new List<GameObject>();
            objDict.Add(road.name, objList);
        }
        initRoad(0);
        initRoad(1);
    }

    // Update is called once per frame
    void Update()
    {

    }

    // 切出新的道路（새로운 도로 생성）
    public void changeRoad(Transform arrivePos)
    {
        int index = arrivePosList.IndexOf(arrivePos);
        if (index >= 0)
        {
            int lastIndex = index - 1;
            if (lastIndex < 0)
                lastIndex = roadList.Count - 1;
            // 移动道路（이동 도로）
            roadList[index].position = roadList[lastIndex].position + new Vector3(roadDistance, 0, 0);

            initRoad(index);
        }
        else
        {
            Debug.LogError("arrivePos index is error");
            return;
        }
    }

    void initRoad(int index)
    {


        // 清空已有障碍物（기존 장애물을 비운다.）
        string roadName = roadList[index].name;       
        foreach (GameObject obj in objDict[roadName])
        {
            Destroy(obj);
        }
        objDict[roadName].Clear();


        // 添加障碍物（장애물 추가）
        foreach (Transform pos in bornPosList[index])
        {
            GameObject prefab = objPrefabList[Random.Range(0, objPrefabList.Count)];
            Vector3 eulerAngle = new Vector3(0, Random.Range(0, 360), 0);
            GameObject obj = Instantiate(prefab, pos.position, Quaternion.EulerAngles(eulerAngle)) as GameObject;
            obj.tag = "Obstacle";
            objDict[roadName].Add(obj);
        }
    }
}
