﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class moveController : MonoBehaviour
{
    // 摄像机位置（카메라 위치）
    public Transform cameraTransform;
    // 摄像机距离人物的距离（카메라에서 사람까지의 거리）
    public float cameraDistance;
    // 游戏管理器（게임 관리자）
    public GameManager gameManager;
    // 前进移动速度（전진 이동 속도）
    float moveVSpeed;
    // 水平移动速度（수평 이동 속도）
    public float moveHSpeed = 5.0f;
    // 跳跃高度（높이뛰기）（구현되지 않음）
    public float jumpHeight = 5.0f;
    // 动画播放器（애니메이션 플레이어）（구현되지 않음）
    Animator m_animator;

    // 跳跃标志（점프）（구현되지 않음）
    int m_jumpState = 0;
    // 最大速度（최대 속도）
    public float maxVSpeed = 8.0f;
    // 最小速度（최저 속도）
    public float minVSpeed = 5.0f;

    // Use this for initialization
    void Start()
    {
        GetComponent<Rigidbody>().freezeRotation = true;
        m_animator = GetComponent<Animator>();
        if (m_animator == null)
            print("null");
        //定义moveVSpeed的初始值（ moveVSpeed의 초기 값을 정의.）
        moveVSpeed = minVSpeed;
    }

    // Update is called once per frame
    void Update()
    {

        //角色可以移动（문자가 움직일 수 있음）


        float h = Input.GetAxis("Horizontal");
        Vector3 vSpeed = new Vector3(this.transform.forward.x, this.transform.forward.y, this.transform.forward.z) * moveVSpeed;
        Vector3 hSpeed = new Vector3(this.transform.right.x, this.transform.right.y, this.transform.right.z) * moveHSpeed * h;
        Vector3 jumpSpeed = new Vector3(this.transform.up.x, this.transform.up.y, this.transform.up.z) * jumpHeight * m_jumpState;
        // 设置摄像机移动速度（카메라 이동 속도 설정）
        Vector3 vCameraSpeed = new Vector3(this.transform.forward.x, this.transform.forward.y, this.transform.forward.z) * minVSpeed;

        // 让摄像机跑起来（카메라를 실행 시키십시오.）
        this.transform.position += (vSpeed + hSpeed + jumpSpeed) * Time.deltaTime;
        cameraTransform.position += (vCameraSpeed) * Time.deltaTime;
      

    }
    void OnGUI()
    {
        if (gameManager.isEnd)
        {
            GUIStyle style = new GUIStyle();

            style.alignment = TextAnchor.MiddleCenter;
            style.fontSize = 40;
            style.normal.textColor = Color.red;
            GUI.Label(new Rect(Screen.width / 2 - 100, Screen.height / 2 - 50, 200, 100), "你输了~", style);

        }
    }

    void OnTriggerEnter(Collider other)
    {
        // 如果是抵达点（도착 지점 인 경우）
        if (other.name.Equals("ArrivePos"))
        {
            gameManager.changeRoad(other.transform);
        }
        // 如果是透明墙（투명한 벽 인 경우）
        else if (other.tag.Equals("AlphaWall"))
        {
            // 没啥事情（상황 없음）
        }
        // 如果是障碍物（장애물 인 경우）
        else if (other.tag.Equals("Obstacle"))
        {

        }
    }
}
