﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Move : MonoBehaviour {

    // 공의 속도 조절을 위한 변수
    public int speed;

    // 공의 방향을 설정하기 위해 변수 생성
    private int Mode;
    // 공을 완전히 멈추기 위한 타이머 시작
    private float timer = -1.0f; // 타이머를 돌지 않게 하기 위해 -1로 초기 값 지정
    // 공을 완전히 멈추기 위한 타이머 끝
    private float E_timer = 0.2f;
    // Player의 RigidBody
    private Rigidbody rb;

	void Start () {
        Mode = 0;
        rb = GetComponent<Rigidbody>();
	}
	
	void Update () {
        //모드를 4 -> 0 으로 바꾸기 위함
        if (Mode > 3)
        {
            Mode = Mode % 4;
        }

        //모드를 음수에서 양수로 바꾸기 위함
        if (Mode < 0)
        {
            Mode = Mode + 4;
        }

        // 현재 모드에 따른 디폴트 전진
        switch (Mode)
        {
            // Z가 증가하는 방향으로 디폴트 전진
            case 0:
                rb.AddForce(Vector3.forward * speed);
                break;
            // X가 감소하는 방향으로 디폴트 전진
            case 1:
                rb.AddForce(Vector3.left * speed);
                break;
            // Z가 감소하는 방향으로 디폴트 전진
            case 2:
                rb.AddForce(Vector3.back * speed);
                break;
            // X가 증가하는 방향으로 디폴트 전진
            case 3:
                rb.AddForce(Vector3.right * speed);
                break;
        }

        // AddForce를 사용하여 밀리는 현상을 없애기 위해 사용
        if ((timer >= 0.0f) && timer < E_timer)
        {
            timer += Time.deltaTime;

            // 속도를 0으로 고정
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

        }

        // 왼쪽 방향키를 입력 받았을 때
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Mode += 1;
            timer = 0.0f;
        }

        // 오른쪽 방향키를 입력 받았을 때
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            Mode -= 1;
            timer = 0.0f;
        }
    }
}
