﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cameramove : MonoBehaviour {

    public Transform obj;
    private Vector3 xyz;

	void Start () {
        xyz = transform.position - obj.transform.position;
	}
	
	void LateUpdate () {
        transform.position = obj.transform.position + xyz;
	}
}
